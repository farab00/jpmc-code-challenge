package com.jpmc.code.challenge.models;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;

@Model(adaptables={SlingHttpServletRequest.class,Resource.class},resourceType="jpmc/components/content/breadcrumb")
@Exporter(name = "jackson", extensions = "json")

public class BreadCrumbs {
  
  private static final Logger LOG = LoggerFactory.getLogger(BreadCrumbs.class);
  
  protected static final int DEFAULT_LEVEL_TO_START_BREADCRUMBS = 1;
  protected static final boolean DEFAULT_INCLUDE_HIDDEN_PAGE = false;
  
  @ScriptVariable
    private Style currentStyle;

  @ScriptVariable
    private Page currentPage;
    
  @ScriptVariable
    private ValueMap properties;

    private int breadcrumbsStartLevel;
    
    private boolean includeHiddenPage;
    
    private List<Page> breadcrumbsPagesList;
    
    public List<Page> getBreadCrumbsList() {
      return breadcrumbsPagesList;
  }
    
    @PostConstruct
    protected void init() {
      LOG.info("BreadCrumbs Initiated");
      try{
        
        if(breadcrumbsPagesList == null)
        	breadcrumbsPagesList = new ArrayList();
        
        // Set entry point for Breads Crumbs navigation
        breadcrumbsStartLevel = DEFAULT_LEVEL_TO_START_BREADCRUMBS;
        
        // Retrieve value set for 'Include Hidden Page' flag within jpmc-global-breadcrumbs component.
        includeHiddenPage = properties.get("includeHiddenPage", currentStyle.get("includeHiddenPage", DEFAULT_INCLUDE_HIDDEN_PAGE));
        
        if(LOG.isDebugEnabled()){
          LOG.debug("--> Set entry point for Breads Crumbs:"+breadcrumbsStartLevel);
          LOG.debug("--> Retrieve value set for 'Exclude Hidden Pages':"+includeHiddenPage);
        }
        
        // Get current page depth
        int currentPageDepth = currentPage.getDepth();
        
        if(LOG.isDebugEnabled()){
          LOG.debug("--> Current Page Depth:"+currentPageDepth);
        }
        
        
        // Build the BreadCrumbs list starting from the selected page.
        while (breadcrumbsStartLevel < currentPageDepth) {
        	
        	if(LOG.isDebugEnabled()){
        		LOG.debug("--> breadcrumbsStartLevel:"+breadcrumbsStartLevel);
        		LOG.debug("--> Current Page Depth:"+currentPageDepth);
        	}
        	
              Page page = currentPage.getAbsoluteParent(breadcrumbsStartLevel);
              if (page != null) {
            	  if (!page.isHideInNav() || includeHiddenPage) {
            		  breadcrumbsPagesList.add(page);
                  }
              }
              
              breadcrumbsStartLevel++;
        }
      }catch(Exception e){
        LOG.error("An ERROR occured activating breadcrumbs component:"+e.getMessage());
        e.printStackTrace();
      }
    }
}


